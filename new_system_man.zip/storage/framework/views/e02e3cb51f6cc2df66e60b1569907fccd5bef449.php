<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class=" mt-2">
            <?php echo e(Form::label('Rut')); ?>

            <?php echo e(Form::text('rut', $client->rut, ['class' => 'form-control' . ($errors->has('rut') ? ' is-invalid' : ''), 'placeholder' => 'Rut'])); ?>

            <?php echo $errors->first('rut', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('name', $client->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('Apellido')); ?>

            <?php echo e(Form::text('last_name', $client->last_name, ['class' => 'form-control' . ($errors->has('last_name') ? ' is-invalid' : ''), 'placeholder' => 'Apellido'])); ?>

            <?php echo $errors->first('last_name', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('email')); ?>

            <?php echo e(Form::text('email', $client->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('Telefono')); ?>

            <?php echo e(Form::text('phone_number', $client->phone_number, ['class' => 'form-control' . ($errors->has('phone_number') ? ' is-invalid' : ''), 'placeholder' => 'Telefono'])); ?>

            <?php echo $errors->first('phone_number', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('razon_social')); ?>

            <?php echo e(Form::text('razon_social', $client->razon_social, ['class' => 'form-control' . ($errors->has('razon_social') ? ' is-invalid' : ''), 'placeholder' => 'Razon Social'])); ?>

            <?php echo $errors->first('razon_social', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('Datos Complentarios')); ?>

            <?php echo e(Form::text('complementary_data', $client->complementary_data, ['class' => 'form-control' . ($errors->has('complementary_data') ? ' is-invalid' : ''), 'placeholder' => 'Complementary Data'])); ?>

            <?php echo $errors->first('complementary_data', '<div class="invalid-feedback">:message</div>'); ?>

        </div>
        <div class=" mt-2">
            <?php echo e(Form::label('Imagen')); ?>

            <?php echo e(Form::text('profile_photo_path', $client->profile_photo_path, ['class' => 'form-control' . ($errors->has('profile_photo_path') ? ' is-invalid' : ''), 'placeholder' => 'Imagen'])); ?>

            <?php echo $errors->first('profile_photo_path', '<div class="invalid-feedback">:message</div>'); ?>

        </div>

    </div>
    <div class="box-footer pt mt-3">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH D:\webs\new_system_man\resources\views/client/form.blade.php ENDPATH**/ ?>