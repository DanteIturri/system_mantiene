<?php $__env->startSection('template_title'); ?>
    <?php echo e($client->name ?? 'Show Client'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Cliente</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('clients.index')); ?>"> Volver</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Rut:</strong>
                            <?php echo e($client->rut); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($client->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Apellido:</strong>
                            <?php echo e($client->last_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email:</strong>
                            <?php echo e($client->email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Telefono:</strong>
                            <?php echo e($client->phone_number); ?>

                        </div>
                        <div class="form-group">
                            <strong>Razon Social:</strong>
                            <?php echo e($client->razon_social); ?>

                        </div>
                        <div class="form-group">
                            <strong>Datos complementario:</strong>
                            <?php echo e($client->complementary_data); ?>

                        </div>
                        <div class="form-group">
                            <strong>Imagen:</strong>
                            <?php echo e($client->profile_photo_path); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webs\new_system_man\resources\views/client/show.blade.php ENDPATH**/ ?>